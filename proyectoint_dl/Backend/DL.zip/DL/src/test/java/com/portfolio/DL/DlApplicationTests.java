package com.portfolio.DL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlApplicationTests {

	@Test
	void contextLoads() {
	}

}
